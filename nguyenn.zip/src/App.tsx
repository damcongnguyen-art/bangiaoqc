/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import { Upload, FileSpreadsheet, Calculator, AlertCircle, Table as TableIcon, Filter, Settings, CheckCircle2, FileCheck, X, Hash, User, Clock, Layers } from 'lucide-react';
import ExcelJS from 'exceljs';
import { format, isValid } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type RowData = Record<string, any>;

interface Mappings {
  date: string;
  order: string;
  inspector: string;
  shift: string;
}

interface Filters {
  date: string;
  order: string;
  inspector: string;
  shift: string;
  line: string;
}

const findInspectorColumn = (headers: string[]): string => {
  // First priority: starts with '2026' (handles '2026 ', '2026.', '2026_') or contains '2026'
  const match2026 = headers.find(h => {
    const lh = h.toLowerCase().trim();
    return lh.startsWith('2026') || lh.includes('2026');
  });
  if (match2026) return match2026;

  // Second priority: keywords
  const keywords = ['kiểm tra vào ca', 'người kiểm tra', 'nguoi kiem tra', 'kỹ thuật viên', 'fqc', 'qc'];
  return headers.find(h => {
    const lh = h.toLowerCase().trim();
    return keywords.some(k => lh.includes(k));
  }) || '';
};

const findShiftColumn = (headers: string[]): string => {
  // 1. Highest Priority: "nhập tay (1)", "nhap tay (1)", "nhập tay(1)", "nhap tay(1)", "nhập tay 1", "nhap tay 1", "nhập tay_1"
  const matchNhapTay1 = headers.find(h => {
    const lh = h.toLowerCase().trim();
    return lh.includes('nhập tay (1)') || 
           lh.includes('nhập tay(1)') || 
           lh.includes('nhap tay (1)') || 
           lh.includes('nhap tay(1)') || 
           lh.includes('nhập tay 1') || 
           lh.includes('nhap tay 1') || 
           lh.includes('nhập tay_1') || 
           lh.includes('nhap tay_1');
  });
  if (matchNhapTay1) return matchNhapTay1;

  // 2. Second Priority: "nhập tay ca", "nhap tay ca"
  const matchNhapTayCa = headers.find(h => {
    const lh = h.toLowerCase().trim();
    return lh === 'nhập tay ca' || lh.includes('nhập tay ca') || lh.includes('nhap tay ca');
  });
  if (matchNhapTayCa) return matchNhapTayCa;

  // 3. Third Priority: "ca làm việc", "ca lam viec", "ca"
  const matchCa = headers.find(h => {
    const lh = h.toLowerCase().trim();
    return lh.includes('ca làm việc') || lh.includes('ca lam viec') || lh === 'ca' || lh.startsWith('ca ');
  });
  if (matchCa) return matchCa;

  // 4. Fourth Priority: any header containing "nhập tay" / "nhap tay"
  const matchAnyNhapTay = headers.find(h => {
    const lh = h.toLowerCase().trim();
    return lh.includes('nhập tay') || lh.includes('nhap tay');
  });
  if (matchAnyNhapTay) return matchAnyNhapTay;

  return '';
};

const formatShiftName = (rawShift: string): string => {
  if (!rawShift) return '';
  const s = rawShift.trim();
  if (!s || s === 'Chưa xác định') return s;
  const lower = s.toLowerCase();
  if (lower.startsWith('ca ') || lower.startsWith('ca-') || lower.startsWith('ca_')) {
    return lower;
  }
  if (lower === 'ca') {
    return 'ca';
  }
  return `ca ${lower}`;
};

const LINE_MAPPING: Record<string, string> = {
  '06': 'AT1',
  '09': 'AT2',
  '05': 'ELI',
  '31': '30L',
  '12': '15L',
  '22': '20L',
  '08': 'PRO'
};

const getLineFromScan = (scanCode: string): { lineCode: string; lineName: string } => {
  const clean = String(scanCode || '').trim();
  if (clean.length < 7) {
    return { lineCode: '', lineName: 'Khác' };
  }
  // Extract 2 first digits of the last 7 digits in scan code
  const last7 = clean.slice(-7);
  const lineCode = last7.slice(0, 2);
  const lineName = LINE_MAPPING[lineCode] || (lineCode ? `Line ${lineCode}` : 'Khác');
  return { lineCode, lineName };
};

const getLineBadgeStyle = (line: string) => {
  switch (line) {
    case 'AT1':
      return 'bg-blue-50 text-blue-700 border-blue-200';
    case 'AT2':
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'ELI':
      return 'bg-indigo-50 text-indigo-700 border-indigo-200';
    case '30L':
      return 'bg-orange-50 text-orange-700 border-orange-200';
    case '15L':
      return 'bg-amber-50 text-amber-700 border-amber-200';
    case '20L':
      return 'bg-cyan-50 text-cyan-700 border-cyan-200';
    case 'PRO':
      return 'bg-rose-50 text-rose-700 border-rose-200';
    default:
      return 'bg-slate-100 text-slate-700 border-slate-200';
  }
};

const guessMapping = (headers: string[], type: 'date' | 'order') => {
  const keywords = {
    date: ['ngày', 'date', 'thời gian', 'ngay'],
    order: ['scan', 'quẹt', 'mã vạch', 'barcode', 'đơn hàng', 'mã đơn', 'po', 'lsx', 'lệnh sản xuất', 'order', 'don hang']
  };
  const targets = keywords[type];
  for (const header of headers) {
    const lower = header.toLowerCase();
    if (targets.some(k => lower.includes(k))) return header;
  }
  return '';
};

const guessMappingsByData = (headers: string[], rows: RowData[]): Mappings => {
  let dateCol = '';
  let orderCol = '';

  const sampleRows = rows.slice(0, 50);

  const scores = headers.map(header => {
    let dateScore = 0;
    let scanScore = 0;

    const lowerHeader = header.toLowerCase();

    // 1. Keyword check (base weight)
    if (['ngày', 'date', 'thời gian', 'ngay'].some(k => lowerHeader.includes(k))) {
      dateScore += 20;
    }
    if (['scan', 'quẹt', 'mã vạch', 'barcode', 'đơn hàng', 'mã đơn', 'po', 'lsx', 'lệnh sản xuất', 'order', 'don hang'].some(k => lowerHeader.includes(k))) {
      scanScore += 15;
    }

    // 2. Data inspection checks
    let dateMatchCount = 0;
    let scanMatchCount = 0;
    let totalValidCells = 0;

    sampleRows.forEach(row => {
      const val = row[header];
      if (val !== undefined && val !== null && val !== '') {
        totalValidCells++;
        const strVal = String(val).trim();

        // Check for 21-digit scan codes or strings that contain mostly numbers and are around 21 chars
        const cleanDigitsOnly = strVal.replace(/\D/g, ''); // strip any non-digits
        
        if (/^\d{21}$/.test(strVal)) {
          scanScore += 15; // direct match of exactly 21 digits
          scanMatchCount++;
        } else if (cleanDigitsOnly.length === 21) {
          scanScore += 12; // holds exactly 21 digits
          scanMatchCount++;
        } else if (strVal.length === 21) {
          scanScore += 8; // length is exactly 21
          scanMatchCount += 0.5;
        } else if (strVal.length >= 18 && strVal.length <= 24 && /^\d+$/.test(strVal)) {
          scanScore += 5;
          scanMatchCount += 0.3;
        }

        // Check for dates
        if (val instanceof Date) {
          dateMatchCount++;
        } else if (/^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}$/.test(strVal)) {
          dateMatchCount++;
        } else if (/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(strVal)) {
          dateMatchCount++;
        }
      }
    });

    if (totalValidCells > 0) {
      const dateRatio = dateMatchCount / totalValidCells;
      const scanRatio = scanMatchCount / totalValidCells;

      dateScore += dateRatio * 150;
      scanScore += scanRatio * 200; // scan matching of 21 digits has the highest weight!
    }

    return {
      header,
      dateScore,
      scanScore
    };
  });

  // Pick best candidates
  let bestDate = scores.reduce((best, curr) => curr.dateScore > best.dateScore ? curr : best, { header: '', dateScore: -1 });
  if (bestDate.dateScore > 10) {
    dateCol = bestDate.header;
  }

  let bestScan = scores.reduce((best, curr) => {
    if (curr.header === dateCol) return best;
    return curr.scanScore > best.scanScore ? curr : best;
  }, { header: '', scanScore: -1 });
  if (bestScan.scanScore > 10) {
    orderCol = bestScan.header;
  }

  // Fallbacks using standard keyword guessing if scores are extremely low or not found
  if (!dateCol) {
    dateCol = guessMapping(headers, 'date');
  }
  if (!orderCol) {
    orderCol = guessMapping(headers, 'order');
  }

  const inspectorCol = findInspectorColumn(headers);
  const shiftCol = findShiftColumn(headers);

  return {
    date: dateCol,
    order: orderCol,
    inspector: inspectorCol,
    shift: shiftCol
  };
};

const parseDateToTime = (dateStr: string): number => {
  if (!dateStr) return 0;
  const parts = dateStr.split('/');
  if (parts.length === 3) {
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const year = parseInt(parts[2], 10);
    const d = new Date(year, month, day);
    if (isValid(d)) return d.getTime();
  }
  const parsed = new Date(dateStr);
  return isValid(parsed) ? parsed.getTime() : 0;
};

const getNewestDate = (data: RowData[], dateCol: string): string => {
  if (!dateCol || !data.length) return '';
  const dates = Array.from(new Set(data.map(r => String(r[dateCol] || '')).filter(Boolean)));
  if (dates.length === 0) return '';

  dates.sort((a: string, b: string) => parseDateToTime(b) - parseDateToTime(a));
  return dates[0] || '';
};

// Simple IndexedDB wrapper for storage persistence
const DB_NAME = 'fqc-calc-db';
const DB_VERSION = 1;
const STORE_NAME = 'app-state';

function initDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function setItem(key: string, value: any): Promise<void> {
  return initDB().then((db) => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(value, key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  });
}

function getItem(key: string): Promise<any> {
  return initDB().then((db) => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  });
}

function clearDB(): Promise<void> {
  return initDB().then((db) => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  });
}

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [persistedFileName, setPersistedFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [headers, setHeaders] = useState<string[]>([]);
  const [data, setData] = useState<RowData[]>([]);
  
  const [mappings, setMappings] = useState<Mappings>({ date: '', order: '', inspector: '', shift: '' });
  const [filters, setFilters] = useState<Filters>({ date: '', order: '', inspector: '', shift: '', line: '' });
  const [extractFirst7, setExtractFirst7] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'summary' | 'details'>('summary');
  const [selectedSummaryItem, setSelectedSummaryItem] = useState<{
    date: string;
    orderCode: string;
    qty: number;
    lineCounts?: Record<string, number>;
  } | null>(null);
  const [expandedInspectorKey, setExpandedInspectorKey] = useState<string | null>(null);
  const [selectedDetailIdx, setSelectedDetailIdx] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Always clear any cached data on startup to return to initial state
  useEffect(() => {
    clearDB().catch(console.error);
  }, []);

  // Helper to format order code (7 digits from scan code)
  const getOrderCode = useCallback((val: any) => {
    if (val === null || val === undefined) return '';
    const str = String(val).trim();
    if (!str) return '';
    return extractFirst7 ? str.substring(0, 7) : str;
  }, [extractFirst7]);

  const processFile = async (selectedFile: File) => {
    try {
      setIsLoading(true);
      setError(null);
      setFile(selectedFile);

      const workbook = new ExcelJS.Workbook();
      const arrayBuffer = await selectedFile.arrayBuffer();
      await workbook.xlsx.load(arrayBuffer);
      
      const worksheet = workbook.worksheets[0];
      if (!worksheet) {
        throw new Error('File không chứa worksheet nào.');
      }

      const rawRows: any[][] = [];
      worksheet.eachRow({ includeEmpty: false }, (row) => {
        // exceljs uses 1-based arrays for row.values
        const rowValues = Array.isArray(row.values) ? row.values.slice(1) : [];
        const cleanedRow = rowValues.map(cell => {
          if (cell === null || cell === undefined) return '';
          if (typeof cell === 'object') {
            if (cell instanceof Date) return cell;
            if ('richText' in cell && Array.isArray(cell.richText)) return cell.richText.map((t: any) => t.text).join('');
            if ('result' in cell) return cell.result; // Formula result
            return String(cell);
          }
          return cell;
        });
        rawRows.push(cleanedRow);
      });

      if (rawRows.length < 2) {
        throw new Error('File Excel không có đủ dữ liệu (ít nhất cần 1 dòng tiêu đề và 1 dòng dữ liệu).');
      }

      // Extract headers and ensure they are strings
      const rawHeaders = rawRows[0].map(h => String(h || '').trim());
      
      // Ensure unique headers just in case
      const uniqueHeaders: string[] = [];
      rawHeaders.forEach((h, i) => {
        let finalHeader = h || `Column ${i + 1}`;
        let counter = 1;
        while (uniqueHeaders.includes(finalHeader)) {
          finalHeader = `${h} (${counter++})`;
        }
        uniqueHeaders.push(finalHeader);
      });

      // Parse data rows
      const parsedData: RowData[] = rawRows.slice(1).map((row) => {
        const obj: RowData = {};
        row.forEach((cell, i) => {
          if (uniqueHeaders[i]) {
            obj[uniqueHeaders[i]] = cell;
          }
        });
        return obj;
      });

      // Clean dates
      const cleanedData = parsedData.map(row => {
        const newRow = { ...row };
        uniqueHeaders.forEach(h => {
          const val = row[h];
          if (val instanceof Date) {
            if (isValid(val)) {
              newRow[h] = format(val, 'dd/MM/yyyy');
            } else {
              newRow[h] = '';
            }
          } else if (typeof val === 'string' && val.includes('T') && val.includes('Z')) {
             // Fallback for string dates if they look like ISO
             const d = new Date(val);
             if (isValid(d)) {
               newRow[h] = format(d, 'dd/MM/yyyy');
             }
          }
        });
        return newRow;
      });

      setHeaders(uniqueHeaders);
      setData(cleanedData);
      setPersistedFileName(selectedFile.name);

      // Guess initial mappings using our advanced data analyzer
      const initialMappings = guessMappingsByData(uniqueHeaders, cleanedData);
      setMappings(initialMappings);
      
      // Automatically select the newest date
      const newestDate = getNewestDate(cleanedData, initialMappings.date);
      const initialFilters = { date: newestDate, order: '' };
      setFilters(initialFilters);
    } catch (err: any) {
      setError(err.message || 'Có lỗi xảy ra khi đọc file. Vui lòng kiểm tra lại định dạng file.');
      setHeaders([]);
      setData([]);
      setPersistedFileName('');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleClearFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setFile(null);
    setPersistedFileName('');
    setData([]);
    setHeaders([]);
    setMappings({ date: '', order: '', inspector: '', shift: '' });
    setFilters({ date: '', order: '', inspector: '', shift: '', line: '' });
    clearDB().catch(console.error);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Find inspector and shift headers
  const inspectorHeader = useMemo(() => {
    return mappings.inspector || findInspectorColumn(headers);
  }, [headers, mappings.inspector]);

  const shiftHeader = useMemo(() => {
    return mappings.shift || findShiftColumn(headers);
  }, [headers, mappings.shift]);

  // Helper to deduce inspector, shift and production line from each scan row (on the exact same row)
  const getRowInspectorAndShift = useCallback((row: RowData) => {
    const inspCol = mappings.inspector || inspectorHeader;
    const shfCol = mappings.shift || shiftHeader;

    let inspector = inspCol ? String(row[inspCol] ?? '').trim() : '';
    let shift = shfCol ? String(row[shfCol] ?? '').trim() : '';

    // Search keys on the same row if not yet matched
    if (!inspector) {
      const k2026 = Object.keys(row).find(k => {
        const lk = k.toLowerCase().trim();
        return lk.startsWith('2026') || lk.includes('2026');
      });
      if (k2026 && row[k2026] !== undefined && row[k2026] !== null) {
        inspector = String(row[k2026]).trim();
      }
    }

    if (!shift) {
      // 1. Check for "nhập tay (1)", "nhap tay (1)", "nhập tay 1"
      const kShift1 = Object.keys(row).find(k => {
        const lk = k.toLowerCase().trim();
        return lk.includes('nhập tay (1)') || 
               lk.includes('nhập tay(1)') || 
               lk.includes('nhap tay (1)') || 
               lk.includes('nhap tay(1)') || 
               lk.includes('nhập tay 1') || 
               lk.includes('nhap tay 1') || 
               lk.includes('nhập tay_1') || 
               lk.includes('nhap tay_1');
      });
      if (kShift1 && row[kShift1] !== undefined && row[kShift1] !== null && String(row[kShift1]).trim() !== '') {
        shift = String(row[kShift1]).trim();
      }
    }

    if (!shift) {
      // 2. Check for "nhập tay ca", "ca làm việc", "ca", etc.
      const kShift = Object.keys(row).find(k => {
        const lk = k.toLowerCase().trim();
        return lk.includes('nhập tay ca') || 
               lk.includes('nhap tay ca') || 
               lk.includes('ca làm việc') || 
               lk.includes('ca lam viec') || 
               lk === 'ca' || 
               lk.startsWith('ca ') || 
               lk.includes('nhập tay') || 
               lk.includes('nhap tay');
      });
      if (kShift && row[kShift] !== undefined && row[kShift] !== null && String(row[kShift]).trim() !== '') {
        shift = String(row[kShift]).trim();
      }
    }

    // Fallback: If not found in explicit columns, check if the raw scan code itself encodes them
    const rawScan = mappings.order ? String(row[mappings.order] || '').trim() : '';
    if (!inspector || !shift) {
      if (rawScan.length > 7) {
        const parts = rawScan.split(/[-_/|,\s]+/);
        if (parts.length >= 2) {
          if (!inspector && parts[1]) inspector = parts[1];
          if (!shift && parts[2]) shift = parts[2];
        }
      }
    }

    const { lineCode, lineName } = getLineFromScan(rawScan);
    const finalShift = shift && shift !== 'Chưa xác định' ? formatShiftName(shift) : 'Chưa xác định';

    return {
      inspector: inspector || 'Chưa xác định',
      shift: finalShift,
      line: lineName,
      lineCode
    };
  }, [inspectorHeader, shiftHeader, mappings.inspector, mappings.shift, mappings.order]);

  // Compute unique values for dropdowns
  const uniqueDates = useMemo(() => {
    if (!mappings.date || !data.length) return [];
    const dates = Array.from(new Set(data.map(r => String(r[mappings.date] || '')).filter(Boolean)));
    return dates.sort((a: string, b: string) => parseDateToTime(b) - parseDateToTime(a));
  }, [data, mappings.date]);

  const uniqueOrders = useMemo(() => {
    if (!mappings.order || !data.length) return [];
    let filteredForOrder = data;
    if (filters.date) {
      filteredForOrder = data.filter(r => String(r[mappings.date]) === filters.date);
    }
    const orders = new Set(filteredForOrder.map(r => getOrderCode(r[mappings.order])).filter(Boolean));
    return Array.from(orders).sort();
  }, [data, mappings.order, filters.date, getOrderCode]);

  const uniqueInspectors = useMemo(() => {
    if (!data.length) return [];
    let scoped = data;
    if (filters.date) scoped = scoped.filter(r => String(r[mappings.date]) === filters.date);
    if (filters.order) scoped = scoped.filter(r => getOrderCode(r[mappings.order]) === filters.order);
    if (filters.line) scoped = scoped.filter(r => getRowInspectorAndShift(r).line === filters.line);
    const inspectors = new Set(scoped.map(r => getRowInspectorAndShift(r).inspector).filter(i => i && i !== 'Chưa xác định'));
    return Array.from(inspectors).sort();
  }, [data, mappings, filters.date, filters.order, filters.line, getOrderCode, getRowInspectorAndShift]);

  const uniqueShifts = useMemo(() => {
    if (!data.length) return [];
    let scoped = data;
    if (filters.date) scoped = scoped.filter(r => String(r[mappings.date]) === filters.date);
    if (filters.order) scoped = scoped.filter(r => getOrderCode(r[mappings.order]) === filters.order);
    if (filters.line) scoped = scoped.filter(r => getRowInspectorAndShift(r).line === filters.line);
    if (filters.inspector) scoped = scoped.filter(r => getRowInspectorAndShift(r).inspector === filters.inspector);
    const shifts = new Set(scoped.map(r => getRowInspectorAndShift(r).shift).filter(s => s && s !== 'Chưa xác định'));
    return Array.from(shifts).sort();
  }, [data, mappings, filters.date, filters.order, filters.line, filters.inspector, getOrderCode, getRowInspectorAndShift]);

  const uniqueLines = useMemo(() => {
    if (!data.length) return [];
    let scoped = data;
    if (filters.date) scoped = scoped.filter(r => String(r[mappings.date]) === filters.date);
    if (filters.order) scoped = scoped.filter(r => getOrderCode(r[mappings.order]) === filters.order);
    if (filters.inspector) scoped = scoped.filter(r => getRowInspectorAndShift(r).inspector === filters.inspector);
    if (filters.shift) scoped = scoped.filter(r => getRowInspectorAndShift(r).shift === filters.shift);
    const lines = new Set(scoped.map(r => getRowInspectorAndShift(r).line).filter(Boolean));
    return Array.from(lines).sort();
  }, [data, mappings, filters.date, filters.order, filters.inspector, filters.shift, getOrderCode, getRowInspectorAndShift]);

  // Compute filtered rows matching current filters
  const filteredData = useMemo(() => {
    if (!mappings.date || !mappings.order) return [];
    const filtered = data.filter(r => {
      const orderCode = getOrderCode(r[mappings.order]);
      if (!orderCode) return false;
      const matchDate = filters.date ? String(r[mappings.date]) === filters.date : true;
      const matchOrder = filters.order ? orderCode === filters.order : true;
      const { inspector, shift, line } = getRowInspectorAndShift(r);
      const matchInspector = filters.inspector ? inspector === filters.inspector : true;
      const matchShift = filters.shift ? shift === filters.shift : true;
      const matchLine = filters.line ? line === filters.line : true;
      return matchDate && matchOrder && matchInspector && matchShift && matchLine;
    });

    // Sort from newest to oldest (descending)
    return filtered.sort((a, b) => {
      const dateA = String(a[mappings.date] || '');
      const dateB = String(b[mappings.date] || '');
      return parseDateToTime(dateB) - parseDateToTime(dateA);
    });
  }, [data, mappings.date, mappings.order, filters, getOrderCode, getRowInspectorAndShift]);

  // Aggregated summary table grouped by (Date, OrderCode)
  const orderSummaryList = useMemo(() => {
    if (!mappings.date || !mappings.order || !data.length) return [];
    
    let scopeData = data;
    if (filters.date) {
      scopeData = scopeData.filter(r => String(r[mappings.date]) === filters.date);
    }
    if (filters.inspector) {
      scopeData = scopeData.filter(r => getRowInspectorAndShift(r).inspector === filters.inspector);
    }
    if (filters.shift) {
      scopeData = scopeData.filter(r => getRowInspectorAndShift(r).shift === filters.shift);
    }
    if (filters.line) {
      scopeData = scopeData.filter(r => getRowInspectorAndShift(r).line === filters.line);
    }

    const map = new Map<string, {
      date: string;
      orderCode: string;
      count: number;
      rawSampleScan: string;
      lineCounts: Record<string, number>;
    }>();

    scopeData.forEach(row => {
      const rowDate = String(row[mappings.date] || 'Không xác định');
      const orderCode = getOrderCode(row[mappings.order]);
      if (!orderCode) return;

      const key = `${rowDate}|||${orderCode}`;
      const rawScan = String(row[mappings.order] || '');
      const { line } = getRowInspectorAndShift(row);

      if (map.has(key)) {
        const existing = map.get(key)!;
        existing.count += 1;
        existing.lineCounts[line] = (existing.lineCounts[line] || 0) + 1;
      } else {
        map.set(key, {
          date: rowDate,
          orderCode,
          count: 1,
          rawSampleScan: rawScan,
          lineCounts: { [line]: 1 }
        });
      }
    });

    const result = Array.from(map.values()).map(item => ({
      ...item,
      qty: item.count,
    }));

    // Sort by date descending (newest to oldest), then by qty descending, then by orderCode
    result.sort((a, b) => {
      const timeA = parseDateToTime(a.date);
      const timeB = parseDateToTime(b.date);
      if (timeB !== timeA) {
        return timeB - timeA;
      }
      if (b.qty !== a.qty) {
        return b.qty - a.qty;
      }
      return a.orderCode.localeCompare(b.orderCode);
    });
    return result;
  }, [data, mappings, filters.date, filters.inspector, filters.shift, filters.line, getOrderCode, getRowInspectorAndShift]);

  // Filter summary list by selected order from dropdown
  const filteredSummaryList = useMemo(() => {
    if (!filters.order) return orderSummaryList;
    return orderSummaryList.filter(item => item.orderCode === filters.order);
  }, [orderSummaryList, filters.order]);

  // Total finished products for current view
  const totalQty = useMemo(() => {
    return filteredData.length;
  }, [filteredData]);

  // Total quantity across all orders in current scope (for % bar calculation)
  const totalScopeQty = useMemo(() => {
    return orderSummaryList.reduce((sum, item) => sum + item.qty, 0);
  }, [orderSummaryList]);

  // Product line classification summary (ELI vs ATMOR vs Khác) based on filtered rows
  const brandClassification = useMemo(() => {
    if (!mappings.order || !filteredData.length) return { eli: 0, atmor: 0, other: 0, total: 0 };
    
    let eli = 0;
    let atmor = 0;
    let other = 0;
    
    filteredData.forEach(row => {
      const qtyVal = 1;
      
      const scanVal = String(row[mappings.order] || '').toUpperCase();
      let detected = false;
      if (scanVal.includes('ELI')) {
        eli += qtyVal;
        detected = true;
      } else if (scanVal.includes('ATMOR') || scanVal.includes('ATM')) {
        atmor += qtyVal;
        detected = true;
      } else {
        // scan other cells in the row
        for (const key in row) {
          if (key === mappings.date) continue;
          const valStr = String(row[key] || '').toUpperCase();
          if (valStr.includes('ELI')) {
            eli += qtyVal;
            detected = true;
            break;
          } else if (valStr.includes('ATMOR') || valStr.includes('ATM')) {
            atmor += qtyVal;
            detected = true;
            break;
          }
        }
      }
      
      if (!detected) {
        other += qtyVal;
      }
    });
    
    return { eli, atmor, other, total: eli + atmor + other };
  }, [filteredData, mappings]);

  // Compute summary of lines for the clicked order
  const selectedOrderLineSummary = useMemo(() => {
    if (!selectedSummaryItem || !mappings.date || !mappings.order || !data.length) return [];

    const matchingRows = data.filter(r => {
      const matchDate = String(r[mappings.date]) === selectedSummaryItem.date;
      const matchOrder = getOrderCode(r[mappings.order]) === selectedSummaryItem.orderCode;
      return matchDate && matchOrder;
    });

    const counts: Record<string, number> = {};
    matchingRows.forEach(r => {
      const { line } = getRowInspectorAndShift(r);
      counts[line] = (counts[line] || 0) + 1;
    });

    return Object.entries(counts).map(([line, count]) => ({
      line,
      count,
      percent: ((count / matchingRows.length) * 100).toFixed(1)
    })).sort((a, b) => b.count - a.count);
  }, [selectedSummaryItem, data, mappings, getOrderCode, getRowInspectorAndShift]);

  // Compute breakdown of inspectors and shifts for the clicked summary item, with line details inside each inspector
  const inspectorBreakdown = useMemo(() => {
    if (!selectedSummaryItem || !mappings.date || !mappings.order || !data.length) return [];

    // Filter rows matching this date and orderCode
    const matchingRows = data.filter(r => {
      const matchDate = String(r[mappings.date]) === selectedSummaryItem.date;
      const matchOrder = getOrderCode(r[mappings.order]) === selectedSummaryItem.orderCode;
      return matchDate && matchOrder;
    });

    // Group by inspector and shift
    const groupMap = new Map<string, { 
      inspector: string; 
      shift: string; 
      count: number; 
      lines: Record<string, number>;
      allScans: string[];
    }>();

    matchingRows.forEach(row => {
      const { inspector, shift, line } = getRowInspectorAndShift(row);
      const rawScan = String(row[mappings.order] || '').trim();
      const key = `${inspector}|||${shift}`;

      if (groupMap.has(key)) {
        const item = groupMap.get(key)!;
        item.count += 1;
        item.lines[line] = (item.lines[line] || 0) + 1;
        if (rawScan && item.allScans.length < 50) {
          item.allScans.push(rawScan);
        }
      } else {
        groupMap.set(key, { 
          inspector, 
          shift, 
          count: 1, 
          lines: { [line]: 1 },
          allScans: rawScan ? [rawScan] : [] 
        });
      }
    });

    return Array.from(groupMap.values()).sort((a, b) => b.count - a.count);
  }, [selectedSummaryItem, data, mappings, getOrderCode, getRowInspectorAndShift]);

  // Check if configuration is complete
  const isConfigComplete = Boolean(mappings.date && mappings.order);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans p-3 sm:p-5">
      <div className="max-w-5xl mx-auto space-y-4">
        
        {/* Top Navigation / Header bar - super compact when data loaded */}
        {data.length > 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg text-white">
                <Calculator className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-bold text-slate-900">Tính tổng sản lượng thành phẩm đã kiểm tra</h1>
                <div className="flex flex-wrap items-center gap-2 mt-0.5">
                  <span className="inline-flex items-center gap-1 text-xs bg-green-50 text-green-700 font-medium px-2 py-0.5 rounded-full border border-green-200">
                    <FileCheck className="w-3.5 h-3.5" />
                    {file?.name || persistedFileName || 'File đã tải'}
                  </span>
                  <span className="text-xs text-slate-500">({data.length.toLocaleString('vi-VN')} dòng)</span>
                </div>
              </div>
            </div>
            
            <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
              {/* Integrated Date filter selection */}
              <div className="flex items-center gap-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 transition-colors">
                <span className="text-xs font-bold text-slate-500 whitespace-nowrap">Chọn Ngày:</span>
                <select 
                  className="bg-transparent text-xs font-bold text-slate-700 focus:outline-none cursor-pointer pr-1"
                  value={filters.date}
                  onChange={(e) => setFilters(f => ({ ...f, date: e.target.value, order: '' }))}
                >
                  <option value="">-- Tất cả ({uniqueDates.length}) --</option>
                  {uniqueDates.map(d => <option key={d as string} value={d as string}>{d as string}</option>)}
                </select>
                {filters.date && (
                  <button 
                    onClick={() => setFilters({ date: '', order: '' })}
                    className="text-xs text-red-500 hover:text-red-700 font-bold ml-1"
                    title="Xóa lọc ngày"
                  >
                    ✕
                  </button>
                )}
              </div>

              <button 
                onClick={handleClearFile}
                className="px-3 py-1.5 bg-slate-50 hover:bg-red-50 text-slate-600 hover:text-red-600 rounded-lg text-xs font-semibold transition-colors border border-slate-200 hover:border-red-200"
              >
                Đổi file Excel khác
              </button>
            </div>
          </div>
        ) : (
          /* Original spacious layout when empty */
          <header className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2.5 bg-blue-600 rounded-xl shadow-sm">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-semibold text-slate-900">Tính tổng sản lượng thành phẩm đã kiểm tra</h1>
            </div>
            <p className="text-slate-500">Ứng dụng hỗ trợ tính tổng số lượng thành phẩm đã kiểm tra theo đơn hàng trong ngày.</p>
          </header>
        )}

        {/* File Upload Zone - only shown when no data */}
        {data.length === 0 && (
          <div 
            className="relative group border-2 border-dashed rounded-2xl p-10 transition-all duration-200 ease-in-out text-center cursor-pointer border-slate-300 bg-white hover:border-blue-400 hover:bg-slate-50"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".xlsx, .xls, .csv" 
              onChange={handleFileChange}
            />
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 bg-blue-50 text-blue-600 rounded-full group-hover:scale-105 transition-transform">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <p className="text-lg font-medium text-slate-700 mb-1">
                  Kéo thả file Excel vào đây
                </p>
                <p className="text-slate-500 text-sm">
                  hoặc click để chọn file từ máy tính
                </p>
              </div>
              {isLoading && <p className="text-blue-600 font-medium animate-pulse mt-2">Đang xử lý file...</p>}
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 text-red-700 p-4 rounded-xl text-sm border border-red-200">
            {error}
          </div>
        )}

        {data.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Bottom Row: Sidebar Filters + Results Table */}
            <div className="md:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
              
              {/* Sidebar Filters */}
              <div className="lg:col-span-3 space-y-4 lg:sticky lg:top-4">
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden p-4 space-y-4">
                  <div className={cn(
                    "flex items-center justify-end border-b border-slate-100 pb-3",
                    !(filters.order || filters.line || filters.inspector || filters.shift) && "hidden"
                  )}>
                    {(filters.order || filters.line || filters.inspector || filters.shift) && (
                      <button
                        onClick={() => setFilters(f => ({ ...f, order: '', line: '', inspector: '', shift: '' }))}
                        className="text-[10px] font-bold text-red-500 hover:text-red-700 transition-colors"
                      >
                        Xóa tất cả bộ lọc
                      </button>
                    )}
                  </div>

                  <div className="space-y-4">
                    {/* Dashboard Summary in Sidebar */}
                    <div className="bg-blue-50/50 border border-blue-100/50 rounded-xl p-3 space-y-2">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                        Tổng sản lượng đã kiểm tra
                      </p>
                      <div className="flex items-baseline gap-1.5">
                        <span className={cn(
                          "text-4xl font-black tracking-tight",
                          totalQty > 0 ? "text-blue-600" : "text-slate-300"
                        )}>
                          {totalQty.toLocaleString('vi-VN')}
                        </span>
                        <span className="text-slate-500 font-bold text-[10px]">thành phẩm</span>
                      </div>
                      
                      <div className="flex flex-col gap-1.5">
                        <div className="text-[11px] text-slate-600 font-medium px-2 py-1 bg-white/50 rounded-lg border border-slate-100">
                          • Tổng hợp <strong>{orderSummaryList.length}</strong> đơn hàng
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-1"></div>

                    {/* Order filter */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                        <Hash className="w-3 h-3" />
                        Mã đơn hàng
                      </label>
                      <select 
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                        value={filters.order}
                        onChange={(e) => setFilters(f => ({ ...f, order: e.target.value }))}
                      >
                        <option value="">Tất cả đơn ({uniqueOrders.length})</option>
                        {uniqueOrders.map(o => <option key={o as string} value={o as string}>{o as string}</option>)}
                      </select>
                    </div>

                    {/* Line filter */}
                    {uniqueLines.length > 0 && (
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <Layers className="w-3 h-3" />
                          Dây chuyền / Line
                        </label>
                        <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                          value={filters.line}
                          onChange={(e) => setFilters(f => ({ ...f, line: e.target.value }))}
                        >
                          <option value="">Tất cả Line ({uniqueLines.length})</option>
                          {uniqueLines.map(l => <option key={l} value={l}>{l}</option>)}
                        </select>
                      </div>
                    )}

                    {/* Inspector filter */}
                    {uniqueInspectors.length > 0 && (
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <User className="w-3 h-3" />
                          Người kiểm tra
                        </label>
                        <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                          value={filters.inspector}
                          onChange={(e) => setFilters(f => ({ ...f, inspector: e.target.value }))}
                        >
                          <option value="">Tất cả ({uniqueInspectors.length})</option>
                          {uniqueInspectors.map(i => <option key={i} value={i}>{i}</option>)}
                        </select>
                      </div>
                    )}

                    {/* Shift filter */}
                    {uniqueShifts.length > 0 && (
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Ca làm việc
                        </label>
                        <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                          value={filters.shift}
                          onChange={(e) => setFilters(f => ({ ...f, shift: e.target.value }))}
                        >
                          <option value="">Tất cả ({uniqueShifts.length})</option>
                          {uniqueShifts.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Data Table Area */}
              <div className="lg:col-span-9">
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-[500px]">
                  
                  {/* Header Tabs */}
                  <div className="px-4 py-2 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
                    <div className="flex items-center gap-1 bg-slate-200/60 p-1 rounded-lg">
                    <button
                      onClick={() => setActiveTab('summary')}
                      className={cn(
                        "px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap",
                        activeTab === 'summary' 
                          ? "bg-white text-blue-600 shadow-sm" 
                          : "text-slate-600 hover:text-slate-900"
                      )}
                    >
                      Phân loại ({orderSummaryList.length})
                    </button>
                    <button
                      onClick={() => setActiveTab('details')}
                      className={cn(
                        "px-3 py-1.5 text-xs font-semibold rounded-md transition-all whitespace-nowrap",
                        activeTab === 'details' 
                          ? "bg-white text-blue-600 shadow-sm" 
                          : "text-slate-600 hover:text-slate-900"
                      )}
                    >
                      Scan ({filteredData.length})
                    </button>
                  </div>
                </div>
                
                {/* Tab Content */}
                <div className="flex-1 overflow-auto">
                  {!isConfigComplete ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center">
                      <FileSpreadsheet className="w-12 h-12 mb-3 opacity-20" />
                      <p>Vui lòng chọn cột Ngày và Mã Đơn Hàng ở khung bên trái để xem kết quả</p>
                    </div>
                  ) : activeTab === 'summary' ? (
                    
                    /* Summary Classification Table */
                    filteredSummaryList.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center">
                        <Filter className="w-10 h-10 mb-3 opacity-20" />
                        <p>Không có đơn hàng nào khớp với tìm kiếm</p>
                      </div>
                    ) : (
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-slate-500 bg-slate-50 sticky top-0 z-10 shadow-sm">
                          <tr>
                            <th className="px-5 py-3 font-medium w-12 text-center">#</th>
                            {!filters.date && <th className="px-5 py-3 font-medium whitespace-nowrap">Ngày</th>}
                            <th className="px-5 py-3 font-medium">Mã đơn</th>
                            <th className="px-5 py-3 font-medium text-right">Sản lượng đã kiểm tra</th>
                            <th className="px-5 py-3 font-medium text-center">Thao tác</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {filteredSummaryList.map((item, idx) => {
                            const isSelected = filters.order === item.orderCode;

                            return (
                              <tr 
                                key={idx} 
                                className={cn(
                                  "hover:bg-blue-50 transition-colors cursor-pointer group relative",
                                  isSelected ? "bg-blue-100/70 shadow-[inset_4px_0_0_0_#2563eb]" : ""
                                )}
                                onClick={() => setFilters(f => ({ ...f, order: isSelected ? '' : item.orderCode }))}
                              >
                                <td className="px-5 py-3 text-slate-400 text-center text-xs">{idx + 1}</td>
                                {!filters.date && (
                                  <td className="px-5 py-3 whitespace-nowrap text-slate-700 text-xs">
                                    {item.date}
                                  </td>
                                )}
                                <td className="px-5 py-3 font-bold text-slate-900 text-xl sm:text-2xl">
                                  <span className="inline-flex items-center gap-1.5">
                                    {item.orderCode}
                                    {isSelected && <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded font-normal">Đang chọn</span>}
                                  </span>
                                </td>
                                <td 
                                  className="px-5 py-3 text-right cursor-pointer hover:underline hover:text-blue-800 transition-all select-none"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedSummaryItem(item);
                                  }}
                                  title="Bấm để xem chi tiết sản lượng từng line và người kiểm tra"
                                >
                                  <div className="flex items-center justify-end gap-2">
                                    <span className="font-black text-blue-600 text-2xl sm:text-3xl tracking-tight">
                                      {item.qty.toLocaleString('vi-VN')}
                                    </span>
                                    <span className="text-[10px] font-semibold bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded border border-blue-100 uppercase flex items-center gap-0.5 shrink-0">
                                      👤 Chi tiết
                                    </span>
                                  </div>
                                </td>
                                <td className="px-5 py-3 text-center">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setFilters(f => ({ ...f, date: item.date, order: item.orderCode }));
                                      setActiveTab('details');
                                    }}
                                    className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-700 rounded-md font-medium transition-colors"
                                  >
                                    Chi tiết scan
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )

                  ) : (
                    
                    /* Detailed Scan Logs Table */
                    filteredData.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center">
                        <Filter className="w-10 h-10 mb-3 opacity-20" />
                        <p>Không có dữ liệu lượt quẹt scan khớp với bộ lọc</p>
                      </div>
                    ) : (
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-slate-500 bg-slate-50 sticky top-0 z-10 shadow-sm">
                          <tr>
                            <th className="px-5 py-3 font-medium w-12 text-center">#</th>
                            <th className="px-5 py-3 font-medium whitespace-nowrap">Ngày</th>
                            <th className="px-5 py-3 font-medium">Mã đơn</th>
                            <th className="px-5 py-3 font-medium">Line</th>
                            {extractFirst7 && <th className="px-5 py-3 font-medium text-slate-400">Mã Quẹt Scan Gốc</th>}
                            <th className="px-5 py-3 font-medium">Người kiểm tra</th>
                            <th className="px-5 py-3 font-medium">Ca làm việc</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {filteredData.slice(0, 150).map((row, idx) => {
                            const rawScan = String(row[mappings.order] || '');
                            const orderCode = getOrderCode(row[mappings.order]);
                            const { inspector, shift, line } = getRowInspectorAndShift(row);
                            return (
                              <tr 
                                key={idx} 
                                className={cn(
                                  "hover:bg-slate-50/80 transition-colors cursor-pointer relative",
                                  selectedDetailIdx === idx ? "bg-blue-100/70 shadow-[inset_4px_0_0_0_#2563eb]" : ""
                                )}
                                onClick={() => setSelectedDetailIdx(selectedDetailIdx === idx ? null : idx)}
                              >
                                <td className="px-5 py-2.5 text-slate-400 w-12 text-center text-xs">{idx + 1}</td>
                                <td className="px-5 py-2.5 whitespace-nowrap text-slate-700 text-xs">{String(row[mappings.date] || '')}</td>
                                <td className="px-5 py-2.5 font-semibold text-slate-900">{orderCode}</td>
                                <td className="px-5 py-2.5 text-xs">
                                  <span className={cn("px-2 py-0.5 rounded font-bold text-[11px] border inline-block", getLineBadgeStyle(line))}>
                                    {line}
                                  </span>
                                </td>
                                {extractFirst7 && <td className="px-5 py-2.5 text-xs text-slate-400 font-mono">{rawScan}</td>}
                                <td className="px-5 py-2.5 text-xs">
                                  <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-medium capitalize border border-blue-100">
                                    👤 {inspector}
                                  </span>
                                </td>
                                <td className="px-5 py-2.5 text-xs">
                                  {shift !== 'Chưa xác định' ? (
                                    <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-semibold rounded text-[11px] uppercase border border-slate-200">
                                      {shift}
                                    </span>
                                  ) : (
                                    <span className="text-slate-400 text-[11px]">-</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )
                  )}

                  {activeTab === 'details' && filteredData.length > 150 && (
                    <div className="text-center py-3 text-xs text-slate-500 bg-slate-50 border-t border-slate-100 sticky bottom-0">
                      Hiển thị 150 / {filteredData.length} lượt quẹt scan đầu tiên...
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

        {/* Detail Breakdown Modal */}
        {selectedSummaryItem && (
          <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden transform transition-all scale-100">
              
              {/* Header */}
              <div className="px-5 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                    Chi tiết sản lượng kiểm tra
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Mã đơn: <span className="font-semibold text-blue-600">{selectedSummaryItem.orderCode}</span> • Ngày: {selectedSummaryItem.date}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedSummaryItem(null)}
                  className="p-1.5 hover:bg-slate-200/60 rounded-lg text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Body */}
              <div className="p-5 max-h-[420px] overflow-y-auto space-y-3">
                {inspectorBreakdown.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 h-8 opacity-25 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span>Không tìm thấy cột thông tin người kiểm tra (tiêu đề chứa "2026") hoặc ca làm việc (tiêu đề "nhập tay ca").</span>
                  </div>
                ) : (
                  <div>
                    <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">
                      👤 Danh sách Người kiểm tra & Ca (bấm để xem chi tiết Line)
                    </div>
                    <div className="divide-y divide-slate-100">
                      {inspectorBreakdown.map((item, idx) => {
                        const itemKey = `${item.inspector}-${item.shift}`;
                        const isExpanded = expandedInspectorKey === itemKey;

                        return (
                          <div key={idx} className="py-2">
                            <div 
                              className={cn(
                                "flex items-center justify-between text-xs sm:text-sm cursor-pointer p-2 rounded-lg transition-colors",
                                isExpanded ? "bg-blue-50/70 border border-blue-100" : "hover:bg-slate-50"
                              )}
                              onClick={() => setExpandedInspectorKey(isExpanded ? null : itemKey)}
                              title="Bấm để xem phân chia số lượng theo Line"
                            >
                              <div className="flex items-center gap-2.5">
                                <span className="font-bold text-slate-800 capitalize text-sm">
                                  {item.inspector} {item.shift && item.shift !== 'Chưa xác định' ? `(${item.shift})` : ''}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-extrabold text-slate-900 bg-white px-2.5 py-1 rounded-lg border border-slate-200 text-xs shadow-2xs">
                                  {item.count.toLocaleString('vi-VN')} <span className="text-[10px] font-normal text-slate-400">thành phẩm</span>
                                </span>
                                <span className="text-[11px] text-slate-400">
                                  {isExpanded ? '▲' : '▼'}
                                </span>
                              </div>
                            </div>

                            {/* Collapsible: Breakdown of Lines & Raw scan codes for this inspector */}
                            {isExpanded && (
                              <div className="mt-2 p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-[11px] space-y-2.5">
                                
                                {/* Production line breakdown for this inspector */}
                                <div>
                                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                                    🏭 Sản lượng theo Line ({item.inspector}):
                                  </div>
                                  <div className="grid grid-cols-2 gap-1.5">
                                    {(Object.entries(item.lines) as [string, number][]).sort((a, b) => b[1] - a[1]).map(([lineName, lCount]) => {
                                      const linePercent = ((lCount / item.count) * 100).toFixed(0);
                                      return (
                                        <div 
                                          key={lineName} 
                                          className="bg-white p-2 rounded-lg border border-slate-200 shadow-2xs flex items-center justify-between"
                                        >
                                          <div className="flex items-center gap-1.5">
                                            <span className={cn("px-1.5 py-0.5 rounded text-[10px] font-bold border", getLineBadgeStyle(lineName))}>
                                              {lineName}
                                            </span>
                                            <span className="text-xs font-bold text-slate-800">
                                              {lCount} <span className="font-normal text-[10px] text-slate-400">sp</span>
                                            </span>
                                          </div>
                                          <span className="text-[10px] font-semibold text-slate-400">{linePercent}%</span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>

                                {/* Raw Scan Codes */}
                                {item.allScans && item.allScans.length > 0 && (
                                  <div className="pt-2 border-t border-slate-200">
                                    <div className="font-bold text-slate-600 mb-1 flex justify-between items-center text-[10px]">
                                      <span>Mã scan gốc ({item.allScans.length} mã):</span>
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setFilters(f => ({ 
                                            ...f, 
                                            date: selectedSummaryItem.date, 
                                            order: selectedSummaryItem.orderCode,
                                            inspector: item.inspector !== 'Chưa xác định' ? item.inspector : '',
                                            shift: item.shift !== 'Chưa xác định' ? item.shift : ''
                                          }));
                                          setSelectedSummaryItem(null);
                                          setActiveTab('details');
                                        }}
                                        className="text-blue-600 hover:text-blue-800 underline font-medium text-[10px]"
                                      >
                                        Xem ở tab Scan →
                                      </button>
                                    </div>
                                    <div className="max-h-24 overflow-y-auto space-y-1 font-mono text-slate-500 divide-y divide-slate-100 text-[10px]">
                                      {item.allScans.map((scanCode, sIdx) => (
                                        <div key={sIdx} className="pt-1 flex items-center justify-between">
                                          <span>{sIdx + 1}. {scanCode}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex justify-between items-center text-xs">
                <span className="text-slate-500 font-semibold">Tổng sản lượng đơn hàng:</span>
                <span className="font-bold text-slate-900 text-sm">{selectedSummaryItem.qty.toLocaleString('vi-VN')} thành phẩm</span>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

